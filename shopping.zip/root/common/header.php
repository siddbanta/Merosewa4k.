<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Quick Kart</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* Custom scrollbar for webkit browsers */
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        /* Disable text selection */
        body { -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; }
        /* Custom loader animation */
        .loader-dots div {
            animation-name: loader-dots;
            animation-duration: 1.5s;
            animation-iteration-count: infinite;
            animation-timing-function: ease-in-out;
        }
        @keyframes loader-dots {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1.0); }
        }
        .loader-dots div:nth-child(1) { animation-delay: -0.32s; }
        .loader-dots div:nth-child(2) { animation-delay: -0.16s; }
    </style>
</head>
<body class="bg-gray-50 font-sans antialiased overflow-x-hidden">
    <!-- Main App Container -->
    <div id="app" class="max-w-md mx-auto bg-white min-h-screen shadow-lg relative">
        <!-- Global Loader Modal -->
        <div id="loader" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
            <div class="bg-white p-6 rounded-lg shadow-xl flex items-center space-x-4">
                <div class="loader-dots relative flex space-x-2">
                    <div class="w-3 h-3 bg-indigo-600 rounded-full"></div>
                    <div class="w-3 h-3 bg-indigo-600 rounded-full"></div>
                    <div class="w-3 h-3 bg-indigo-600 rounded-full"></div>
                </div>
                <span class="text-gray-700 font-medium">Loading...</span>
            </div>
        </div>

        <!-- Global Toast Notification -->
        <div id="toast" class="hidden fixed top-5 right-5 bg-green-500 text-white py-2 px-4 rounded-lg shadow-lg z-50 transition-transform transform translate-x-full">
            <span id="toast-message"></span>
        </div>

        <!-- Sidebar (Mobile Menu) -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content Area -->
        <main class="pb-20">