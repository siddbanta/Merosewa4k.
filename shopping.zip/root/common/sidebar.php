<div id="sidebar-overlay" class="hidden fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity duration-300"></div>
<aside id="sidebar" class="fixed top-0 left-0 h-full w-64 bg-white shadow-xl z-40 transform -translate-x-full transition-transform duration-300 ease-in-out">
    <div class="p-4 border-b">
        <h2 class="text-2xl font-bold text-indigo-600">Quick Kart</h2>
    </div>
    <nav class="mt-4">
        <a href="index.php" class="flex items-center px-4 py-3 text-gray-700 hover:bg-indigo-50">
            <i class="fas fa-home w-6 text-center"></i><span class="ml-3">Home</span>
        </a>
        <a href="order.php" class="flex items-center px-4 py-3 text-gray-700 hover:bg-indigo-50">
            <i class="fas fa-box w-6 text-center"></i><span class="ml-3">My Orders</span>
        </a>
        <a href="profile.php" class="flex items-center px-4 py-3 text-gray-700 hover:bg-indigo-50">
            <i class="fas fa-user-circle w-6 text-center"></i><span class="ml-3">Profile</span>
        </a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="profile.php?action=logout" class="flex items-center px-4 py-3 text-red-500 hover:bg-red-50">
                <i class="fas fa-sign-out-alt w-6 text-center"></i><span class="ml-3">Logout</span>
            </a>
        <?php else: ?>
            <a href="login.php" class="flex items-center px-4 py-3 text-gray-700 hover:bg-indigo-50">
                 <i class="fas fa-sign-in-alt w-6 text-center"></i><span class="ml-3">Login</span>
            </a>
        <?php endif; ?>
    </nav>
</aside>