        </main>

        <!-- Bottom Navigation -->
        <footer class="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-200 shadow-t">
            <nav class="flex justify-around items-center h-16">
                <a href="index.php" class="flex flex-col items-center text-gray-600 hover:text-indigo-600 w-full pt-2 pb-1">
                    <i class="fas fa-home text-xl"></i>
                    <span class="text-xs mt-1">Home</span>
                </a>
                <a href="cart.php" class="relative flex flex-col items-center text-gray-600 hover:text-indigo-600 w-full pt-2 pb-1">
                    <i class="fas fa-shopping-cart text-xl"></i>
                    <span class="text-xs mt-1">Cart</span>
                    <?php 
                    $cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
                    if ($cart_count > 0): ?>
                    <span class="absolute top-0 right-6 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        <?= $cart_count ?>
                    </span>
                    <?php endif; ?>
                </a>
                <a href="profile.php" class="flex flex-col items-center text-gray-600 hover:text-indigo-600 w-full pt-2 pb-1">
                    <i class="fas fa-user text-xl"></i>
                    <span class="text-xs mt-1">Profile</span>
                </a>
            </nav>
        </footer>
    </div> <!-- End #app container -->

<script>
    // --- GLOBAL JS ---
    document.addEventListener('contextmenu', event => event.preventDefault()); // Disable right-click
    document.addEventListener('touchstart', function(e) { // Disable zoom
        if (e.touches.length > 1) {
            e.preventDefault();
        }
    }, { passive: false });
    let lastTouchEnd = 0;
    document.addEventListener('touchend', function(e) {
        const now = (new Date()).getTime();
        if (now - lastTouchEnd <= 300) {
            e.preventDefault();
        }
        lastTouchEnd = now;
    }, false);


    // Loader and Toast functions
    const loader = document.getElementById('loader');
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');

    function showLoader() { loader.classList.remove('hidden'); }
    function hideLoader() { loader.classList.add('hidden'); }

    function showToast(message, isSuccess = true) {
        toastMessage.innerText = message;
        toast.classList.remove('hidden', 'bg-red-500', 'bg-green-500', 'translate-x-full');
        toast.classList.add(isSuccess ? 'bg-green-500' : 'bg-red-500');
        setTimeout(() => { toast.classList.remove('translate-x-full'); }, 10); // Animate in
        
        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => { toast.classList.add('hidden'); }, 300);
        }, 3000);
    }

    // Sidebar toggle logic
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const menuButton = document.getElementById('menu-button'); // This ID must exist on the menu button in headers

    if(menuButton) {
        menuButton.addEventListener('click', () => {
            sidebar.classList.toggle('-translate-x-full');
            sidebarOverlay.classList.toggle('hidden');
        });
    }

    if(sidebarOverlay) {
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.add('-translate-x-full');
            sidebarOverlay.classList.add('hidden');
        });
    }

</script>
</body>
</html>