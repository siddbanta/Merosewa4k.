<?php
// Session start karna zaroori hai login system ke liye
session_start();

// --- DATABASE CONNECTION DETAILS ---
// Inhe apne system ke hisaab se check karein

$db_host = '127.0.0.1';     // Yeh 'localhost' bhi ho sakta hai
$db_user = 'root';          // Yeh aam taur par 'root' hi hota hai
$db_pass = '';              // XAMPP mein password aksar khali hota hai. Agar aapne set kiya hai to woh daalein.
$db_name = 'quickkart_db';  // Apne database ka sahi naam yahan likhein

// Database se connect karne ki koshish
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check karein ki connection safal hua ya nahi
if ($conn->connect_error) {
    // Agar connection fail hota hai, to error dikha kar script ko rok dein
    die("Database Connection Failed: " . $conn->connect_error);
}

// User input ko saaf karne ke liye function (XSS attacks se bachne ke liye)
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>