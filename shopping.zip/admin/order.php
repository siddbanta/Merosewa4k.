<?php
require_once 'common/header.php';

$filter_status = $_GET['status'] ?? 'all';
$where_clause = '';
if ($filter_status !== 'all') {
    $where_clause = "WHERE o.status = '" . $conn->real_escape_string($filter_status) . "'";
}

$orders = $conn->query("
    SELECT o.id, o.total_amount, o.status, o.created_at, u.name as user_name
    FROM orders o
    JOIN users u ON o.user_id = u.id
    $where_clause
    ORDER BY o.created_at DESC
");
?>
<h1 class="text-2xl font-bold text-gray-800 mb-6">Manage Orders</h1>

<!-- Filters -->
<div class="mb-4 flex space-x-2">
    <a href="?status=all" class="px-4 py-2 rounded-lg <?= $filter_status == 'all' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700' ?>">All</a>
    <a href="?status=Placed" class="px-4 py-2 rounded-lg <?= $filter_status == 'Placed' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700' ?>">Placed</a>
    <a href="?status=Dispatched" class="px-4 py-2 rounded-lg <?= $filter_status == 'Dispatched' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700' ?>">Dispatched</a>
    <a href="?status=Delivered" class="px-4 py-2 rounded-lg <?= $filter_status == 'Delivered' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700' ?>">Delivered</a>
    <a href="?status=Cancelled" class="px-4 py-2 rounded-lg <?= $filter_status == 'Cancelled' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700' ?>">Cancelled</a>
</div>

<div class="bg-white rounded-lg shadow-md overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="p-4 font-semibold">Order ID</th>
                    <th class="p-4 font-semibold">User</th>
                    <th class="p-4 font-semibold">Amount</th>
                    <th class="p-4 font-semibold">Status</th>
                    <th class="p-4 font-semibold">Date</th>
                    <th class="p-4 font-semibold">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while($order = $orders->fetch_assoc()): 
                $status_color = match($order['status']) {
                    'Placed' => 'bg-blue-100 text-blue-800',
                    'Dispatched' => 'bg-yellow-100 text-yellow-800',
                    'Delivered' => 'bg-green-100 text-green-800',
                    'Cancelled' => 'bg-red-100 text-red-800',
                    default => 'bg-gray-100 text-gray-800'
                };
            ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="p-4 font-bold text-indigo-600">#<?= $order['id'] ?></td>
                    <td class="p-4"><?= htmlspecialchars($order['user_name']) ?></td>
                    <td class="p-4">₹<?= number_format($order['total_amount']) ?></td>
                    <td class="p-4">
                        <span class="px-2 py-1 text-xs font-semibold rounded-full <?= $status_color ?>">
                            <?= $order['status'] ?>
                        </span>
                    </td>
                    <td class="p-4 text-sm text-gray-600"><?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></td>
                    <td class="p-4">
                        <a href="order_detail.php?id=<?= $order['id'] ?>" class="text-indigo-600 hover:underline">View Details</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>