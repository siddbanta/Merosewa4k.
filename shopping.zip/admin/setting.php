<?php
require_once 'common/header.php';

$admin_id = $_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'];
    $new_username = sanitize_input($_POST['new_username']);
    $new_password = $_POST['new_password'];
    $message = '';
    $is_success = false;
    
    // Fetch current admin details
    $res = $conn->query("SELECT username, password FROM admin WHERE id = $admin_id");
    $admin = $res->fetch_assoc();

    if (password_verify($current_password, $admin['password'])) {
        $update_query = "UPDATE admin SET ";
        $params = [];
        $types = "";
        
        if (!empty($new_username) && $new_username !== $admin['username']) {
            $update_query .= "username = ?";
            $params[] = $new_username;
            $types .= "s";
        }
        
        if (!empty($new_password)) {
            if (!empty($params)) $update_query .= ", ";
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_query .= "password = ?";
            $params[] = $hashed_new_password;
            $types .= "s";
        }
        
        if (!empty($params)) {
            $update_query .= " WHERE id = ?";
            $params[] = $admin_id;
            $types .= "i";
            
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param($types, ...$params);
            if ($stmt->execute()) {
                $message = "Settings updated successfully.";
                $is_success = true;
            } else {
                $message = "Error updating settings.";
            }
        } else {
            $message = "No changes to update.";
        }
    } else {
        $message = "Incorrect current password.";
    }
}
?>
<h1 class="text-2xl font-bold text-gray-800 mb-6">Admin Settings</h1>

<div class="max-w-lg mx-auto bg-white p-8 rounded-lg shadow-md">
    <?php if (isset($message)): ?>
        <div class="<?= $is_success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?> p-4 rounded-md mb-6">
            <?= $message ?>
        </div>
    <?php endif; ?>
    <form method="POST" class="space-y-6">
        <div>
            <label for="current_password" class="block text-sm font-medium text-gray-700">Current Password (Required)</label>
            <input type="password" name="current_password" id="current_password" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
         <hr>
        <div>
            <label for="new_username" class="block text-sm font-medium text-gray-700">New Username (Optional)</label>
            <input type="text" name="new_username" id="new_username" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
        </div>
        <div>
            <label for="new_password" class="block text-sm font-medium text-gray-700">New Password (Optional)</label>
            <input type="password" name="new_password" id="new_password" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
            <p class="text-xs text-gray-500 mt-1">Leave blank to keep the current password.</p>
        </div>
        <button type="submit" class="w-full bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700">
            Save Changes
        </button>
    </form>
</div>
<?php require_once 'common/bottom.php'; ?>