<?php
require_once 'common/config.php'; // Use config from root

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $response = ['status' => 'error', 'message' => 'An error occurred.'];
    
    switch ($_POST['action']) {
        case 'add':
        case 'edit':
            $name = sanitize_input($_POST['name']);
            $id = (int)($_POST['id'] ?? 0);
            $image_name = $_POST['current_image'] ?? '';

            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                // Delete old image if editing and new one is uploaded
                if ($id > 0 && !empty($image_name) && file_exists("../uploads/categories/$image_name")) {
                    unlink("../uploads/categories/$image_name");
                }
                $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $image_name = uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/categories/" . $image_name);
            }

            if ($_POST['action'] === 'add') {
                $stmt = $conn->prepare("INSERT INTO categories (name, image) VALUES (?, ?)");
                $stmt->bind_param("ss", $name, $image_name);
            } else {
                $stmt = $conn->prepare("UPDATE categories SET name = ?, image = ? WHERE id = ?");
                $stmt->bind_param("ssi", $name, $image_name, $id);
            }

            if ($stmt->execute()) {
                $response = ['status' => 'success', 'message' => 'Category saved successfully.'];
            } else {
                $response['message'] = 'Database error.';
            }
            break;

        case 'fetch':
            $id = (int)$_POST['id'];
            $res = $conn->query("SELECT * FROM categories WHERE id = $id");
            $data = $res->fetch_assoc();
            $response = ['status' => 'success', 'data' => $data];
            break;
            
        case 'delete':
            $id = (int)$_POST['id'];
            // Get image name to delete file
            $res = $conn->query("SELECT image FROM categories WHERE id = $id");
            if($res->num_rows > 0) {
                $image_name = $res->fetch_assoc()['image'];
                if(!empty($image_name) && file_exists("../uploads/categories/$image_name")) {
                    unlink("../uploads/categories/$image_name");
                }
            }
            $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $response = ['status' => 'success', 'message' => 'Category deleted.'];
            }
            break;
    }
    
    echo json_encode($response);
    exit();
}

require_once 'common/header.php';
$categories = $conn->query("SELECT * FROM categories ORDER BY name ASC");
?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Manage Categories</h1>
    <button id="add-category-btn" class="bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-indigo-700">
        <i class="fas fa-plus mr-2"></i>Add Category
    </button>
</div>

<!-- Category List -->
<div class="bg-white p-4 rounded-lg shadow-md">
    <div id="category-list" class="space-y-3">
        <?php while ($cat = $categories->fetch_assoc()): ?>
        <div id="cat-<?= $cat['id'] ?>" class="flex items-center justify-between p-3 border rounded-lg">
            <div class="flex items-center">
                <img src="../uploads/categories/<?= htmlspecialchars($cat['image']) ?>" class="w-12 h-12 rounded-md object-contain mr-4 bg-gray-100">
                <span class="font-semibold text-gray-700"><?= htmlspecialchars($cat['name']) ?></span>
            </div>
            <div class="space-x-2">
                <button onclick="editCategory(<?= $cat['id'] ?>)" class="text-blue-500 hover:text-blue-700"><i class="fas fa-edit"></i></button>
                <button onclick="deleteCategory(<?= $cat['id'] ?>)" class="text-red-500 hover:text-red-700"><i class="fas fa-trash-alt"></i></button>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Modal -->
<div id="category-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
        <h2 id="modal-title" class="text-xl font-bold mb-4">Add Category</h2>
        <form id="category-form" enctype="multipart/form-data">
            <input type="hidden" name="action" id="form-action">
            <input type="hidden" name="id" id="category-id">
            <input type="hidden" name="current_image" id="current-image-name">
            <div class="space-y-4">
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700">Category Name</label>
                    <input type="text" name="name" id="category-name" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div>
                    <label for="image" class="block text-sm font-medium text-gray-700">Category Image</label>
                    <input type="file" name="image" id="category-image" class="mt-1 block w-full text-sm">
                    <img id="image-preview" src="#" alt="Preview" class="hidden mt-2 h-20 w-20 object-contain"/>
                </div>
            </div>
            <div class="mt-6 flex justify-end space-x-3">
                <button type="button" id="cancel-btn" class="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Cancel</button>
                <button type="submit" class="bg-indigo-600 text-white py-2 px-4 rounded-lg">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
    const modal = document.getElementById('category-modal');
    const addBtn = document.getElementById('add-category-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    const form = document.getElementById('category-form');
    const modalTitle = document.getElementById('modal-title');
    
    addBtn.onclick = () => {
        form.reset();
        document.getElementById('image-preview').classList.add('hidden');
        modalTitle.textContent = 'Add Category';
        document.getElementById('form-action').value = 'add';
        modal.classList.remove('hidden');
    };
    cancelBtn.onclick = () => modal.classList.add('hidden');

    async function editCategory(id) {
        showLoader();
        const formData = new FormData();
        formData.append('action', 'fetch');
        formData.append('id', id);
        
        const response = await fetch('category.php', { method: 'POST', body: formData });
        const result = await response.json();
        hideLoader();

        if(result.status === 'success') {
            const data = result.data;
            form.reset();
            modalTitle.textContent = 'Edit Category';
            document.getElementById('form-action').value = 'edit';
            document.getElementById('category-id').value = data.id;
            document.getElementById('category-name').value = data.name;
            document.getElementById('current-image-name').value = data.image;
            
            const preview = document.getElementById('image-preview');
            if(data.image) {
                preview.src = `../uploads/categories/${data.image}`;
                preview.classList.remove('hidden');
            } else {
                preview.classList.add('hidden');
            }
            
            modal.classList.remove('hidden');
        }
    }

    async function deleteCategory(id) {
        if (!confirm('Are you sure you want to delete this category?')) return;
        
        showLoader();
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);

        const response = await fetch('category.php', { method: 'POST', body: formData });
        const result = await response.json();
        hideLoader();

        showToast(result.message, result.status === 'success');
        if (result.status === 'success') {
            document.getElementById(`cat-${id}`).remove();
        }
    }

    form.onsubmit = async (e) => {
        e.preventDefault();
        showLoader();
        const formData = new FormData(form);

        const response = await fetch('category.php', { method: 'POST', body: formData });
        const result = await response.json();
        hideLoader();
        
        showToast(result.message, result.status === 'success');
        if (result.status === 'success') {
            modal.classList.add('hidden');
            location.reload(); // Simple reload to show changes
        }
    };
</script>

<?php require_once 'common/bottom.php'; ?>