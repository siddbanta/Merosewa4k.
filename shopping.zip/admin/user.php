<?php
require_once 'common/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    header('Content-Type: application/json');
    $user_id = (int)$_POST['id'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'User deleted successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to delete user.']);
    }
    exit();
}

$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
require_once 'common/header.php';
?>
<h1 class="text-2xl font-bold text-gray-800 mb-6">Manage Users</h1>

<div class="bg-white rounded-lg shadow-md overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-50 border-b">
                <tr>
                    <th class="p-4 font-semibold">Name</th>
                    <th class="p-4 font-semibold">Email</th>
                    <th class="p-4 font-semibold">Phone</th>
                    <th class="p-4 font-semibold">Joined On</th>
                    <th class="p-4 font-semibold">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while($user = $users->fetch_assoc()): ?>
                <tr id="user-<?= $user['id'] ?>" class="border-b hover:bg-gray-50">
                    <td class="p-4"><?= htmlspecialchars($user['name']) ?></td>
                    <td class="p-4 text-gray-600"><?= htmlspecialchars($user['email']) ?></td>
                    <td class="p-4 text-gray-600"><?= htmlspecialchars($user['phone']) ?></td>
                    <td class="p-4 text-sm text-gray-500"><?= date('d M Y', strtotime($user['created_at'])) ?></td>
                    <td class="p-4">
                        <button onclick="deleteUser(<?= $user['id'] ?>)" class="text-red-500 hover:text-red-700">
                            <i class="fas fa-trash-alt"></i> Delete
                        </button>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
async function deleteUser(id) {
    if (!confirm('Are you sure you want to delete this user and all their associated orders?')) return;
    showLoader();
    const formData = new FormData();
    formData.append('action', 'delete');
    formData.append('id', id);

    const response = await fetch('user.php', { method: 'POST', body: formData });
    const result = await response.json();
    hideLoader();
    showToast(result.message, result.status === 'success');
    if (result.status === 'success') {
        document.getElementById(`user-${id}`).remove();
    }
}
</script>

<?php require_once 'common/bottom.php'; ?>