<?php
require_once 'common/config.php';

// AJAX Handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $response = ['status' => 'error', 'message' => 'An error occurred.'];

    switch ($_POST['action']) {
        case 'add':
        case 'edit':
            $id = (int)($_POST['id'] ?? 0);
            $cat_id = (int)$_POST['cat_id'];
            $name = sanitize_input($_POST['name']);
            $description = sanitize_input($_POST['description']);
            $price = (float)$_POST['price'];
            $stock = (int)$_POST['stock'];
            $image_name = $_POST['current_image'] ?? '';

            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                if ($id > 0 && !empty($image_name) && file_exists("../uploads/products/$image_name")) {
                    unlink("../uploads/products/$image_name");
                }
                $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $image_name = uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/products/" . $image_name);
            }

            if ($_POST['action'] === 'add') {
                $stmt = $conn->prepare("INSERT INTO products (cat_id, name, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("issdis", $cat_id, $name, $description, $price, $stock, $image_name);
            } else {
                $stmt = $conn->prepare("UPDATE products SET cat_id=?, name=?, description=?, price=?, stock=?, image=? WHERE id=?");
                $stmt->bind_param("issdisi", $cat_id, $name, $description, $price, $stock, $image_name, $id);
            }

            if ($stmt->execute()) {
                $response = ['status' => 'success', 'message' => 'Product saved successfully.'];
            } else {
                $response['message'] = 'Database error: ' . $stmt->error;
            }
            break;

        case 'fetch':
            $id = (int)$_POST['id'];
            $res = $conn->query("SELECT * FROM products WHERE id = $id");
            $response = ['status' => 'success', 'data' => $res->fetch_assoc()];
            break;

        case 'delete':
            $id = (int)$_POST['id'];
            $res = $conn->query("SELECT image FROM products WHERE id = $id");
            if ($res->num_rows > 0) {
                $image_name = $res->fetch_assoc()['image'];
                if (!empty($image_name) && file_exists("../uploads/products/$image_name")) {
                    unlink("../uploads/products/$image_name");
                }
            }
            $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $response = ['status' => 'success', 'message' => 'Product deleted.'];
            }
            break;
    }

    echo json_encode($response);
    exit();
}

require_once 'common/header.php';
$products = $conn->query("SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.cat_id = c.id ORDER BY p.created_at DESC");
$categories = $conn->query("SELECT * FROM categories ORDER BY name ASC");
?>
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Manage Products</h1>
    <button id="add-product-btn" class="bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:bg-indigo-700">
        <i class="fas fa-plus mr-2"></i>Add Product
    </button>
</div>

<!-- Product List -->
<div class="bg-white p-4 rounded-lg shadow-md">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
    <?php while ($prod = $products->fetch_assoc()): ?>
        <div id="prod-<?= $prod['id'] ?>" class="border rounded-lg p-4 flex flex-col">
            <img src="../uploads/products/<?= htmlspecialchars($prod['image']) ?>" class="w-full h-40 object-cover rounded-md mb-4">
            <h3 class="font-bold text-lg text-gray-800"><?= htmlspecialchars($prod['name']) ?></h3>
            <p class="text-sm text-gray-500 mb-2"><?= htmlspecialchars($prod['category_name']) ?></p>
            <p class="text-indigo-600 font-bold text-xl mb-2">₹<?= number_format($prod['price']) ?></p>
            <p class="text-sm text-gray-600 mb-4">Stock: <span class="font-semibold"><?= $prod['stock'] ?></span></p>
            <div class="mt-auto flex justify-end space-x-2">
                <button onclick="editProduct(<?= $prod['id'] ?>)" class="text-blue-500 hover:text-blue-700 p-2"><i class="fas fa-edit"></i> Edit</button>
                <button onclick="deleteProduct(<?= $prod['id'] ?>)" class="text-red-500 hover:text-red-700 p-2"><i class="fas fa-trash-alt"></i> Delete</button>
            </div>
        </div>
    <?php endwhile; ?>
    </div>
</div>

<!-- Modal -->
<div id="product-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 overflow-y-auto">
    <div class="bg-white rounded-lg shadow-xl w-full max-w-lg p-6 my-8">
        <h2 id="modal-title" class="text-xl font-bold mb-4">Add Product</h2>
        <form id="product-form" enctype="multipart/form-data" class="space-y-4">
            <input type="hidden" name="action" id="form-action">
            <input type="hidden" name="id" id="product-id">
            <input type="hidden" name="current_image" id="current-image-name">

            <div>
                <label class="block text-sm font-medium">Category</label>
                <select name="cat_id" id="cat_id" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    <?php mysqli_data_seek($categories, 0); while ($cat = $categories->fetch_assoc()): ?>
                    <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium">Product Name</label>
                <input type="text" name="name" id="name" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
            </div>
            <div>
                <label class="block text-sm font-medium">Description</label>
                <textarea name="description" id="description" rows="3" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"></textarea>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium">Price (₹)</label>
                    <input type="number" name="price" id="price" step="0.01" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div>
                    <label class="block text-sm font-medium">Stock</label>
                    <input type="number" name="stock" id="stock" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
            </div>
             <div>
                <label class="block text-sm font-medium">Product Image</label>
                <input type="file" name="image" id="image" class="mt-1 block w-full text-sm">
                <img id="image-preview" src="#" alt="Preview" class="hidden mt-2 h-24 w-24 object-contain"/>
            </div>

            <div class="mt-6 flex justify-end space-x-3">
                <button type="button" id="cancel-btn" class="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Cancel</button>
                <button type="submit" class="bg-indigo-600 text-white py-2 px-4 rounded-lg">Save Product</button>
            </div>
        </form>
    </div>
</div>

<script>
    // JS for product modal (similar to category)
    const modal = document.getElementById('product-modal');
    const form = document.getElementById('product-form');

    document.getElementById('add-product-btn').onclick = () => {
        form.reset();
        document.getElementById('image-preview').classList.add('hidden');
        document.getElementById('modal-title').textContent = 'Add Product';
        document.getElementById('form-action').value = 'add';
        modal.classList.remove('hidden');
    };
    document.getElementById('cancel-btn').onclick = () => modal.classList.add('hidden');

    async function editProduct(id) {
        showLoader();
        const formData = new FormData();
        formData.append('action', 'fetch');
        formData.append('id', id);
        
        const response = await fetch('product.php', { method: 'POST', body: formData });
        const result = await response.json();
        hideLoader();

        if(result.status === 'success') {
            const data = result.data;
            form.reset();
            document.getElementById('modal-title').textContent = 'Edit Product';
            document.getElementById('form-action').value = 'edit';
            document.getElementById('product-id').value = data.id;
            document.getElementById('cat_id').value = data.cat_id;
            document.getElementById('name').value = data.name;
            document.getElementById('description').value = data.description;
            document.getElementById('price').value = data.price;
            document.getElementById('stock').value = data.stock;
            document.getElementById('current-image-name').value = data.image;

            const preview = document.getElementById('image-preview');
            if (data.image) {
                preview.src = `../uploads/products/${data.image}`;
                preview.classList.remove('hidden');
            } else {
                preview.classList.add('hidden');
            }
            modal.classList.remove('hidden');
        }
    }

    async function deleteProduct(id) {
        if (!confirm('Are you sure you want to delete this product?')) return;
        showLoader();
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);

        const response = await fetch('product.php', { method: 'POST', body: formData });
        const result = await response.json();
        hideLoader();

        showToast(result.message, result.status === 'success');
        if (result.status === 'success') {
            document.getElementById(`prod-${id}`).remove();
        }
    }

    form.onsubmit = async (e) => {
        e.preventDefault();
        showLoader();
        const formData = new FormData(form);

        const response = await fetch('product.php', { method: 'POST', body: formData });
        const result = await response.json();
        hideLoader();
        
        showToast(result.message, result.status === 'success');
        if (result.status === 'success') {
            modal.classList.add('hidden');
            location.reload();
        }
    };
</script>
<?php require_once 'common/bottom.php'; ?>