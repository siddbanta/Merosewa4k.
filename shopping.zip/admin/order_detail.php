<?php
require_once 'common/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    header('Content-Type: application/json');
    $order_id = (int)$_POST['order_id'];
    $status = sanitize_input($_POST['status']);
    
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $order_id);
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Order status updated.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update status.']);
    }
    exit();
}

$order_id = (int)$_GET['id'];
if ($order_id === 0) {
    header('Location: order.php');
    exit();
}

// Get Order and User Details
$order_res = $conn->query("
    SELECT o.*, u.name, u.email, u.phone as user_phone 
    FROM orders o JOIN users u ON o.user_id = u.id 
    WHERE o.id = $order_id
");
$order = $order_res->fetch_assoc();

// Get Order Items
$items_res = $conn->query("
    SELECT oi.*, p.name as product_name, p.image as product_image 
    FROM order_items oi JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = $order_id
");

require_once 'common/header.php';
?>

<div class="flex items-center mb-6">
    <a href="order.php" class="text-gray-600 mr-4"><i class="fas fa-arrow-left"></i></a>
    <h1 class="text-2xl font-bold text-gray-800">Order Details #<?= $order_id ?></h1>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Left Column: Order Items -->
    <div class="lg:col-span-2 bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-semibold mb-4 border-b pb-2">Ordered Items</h2>
        <div class="space-y-4">
            <?php while ($item = $items_res->fetch_assoc()): ?>
            <div class="flex items-center">
                <img src="../uploads/products/<?= htmlspecialchars($item['product_image']) ?>" class="w-16 h-16 rounded-md object-cover mr-4">
                <div class="flex-grow">
                    <p class="font-semibold"><?= htmlspecialchars($item['product_name']) ?></p>
                    <p class="text-sm text-gray-500">Qty: <?= $item['quantity'] ?> @ ₹<?= number_format($item['price']) ?></p>
                </div>
                <p class="font-bold text-indigo-600">₹<?= number_format($item['quantity'] * $item['price']) ?></p>
            </div>
            <?php endwhile; ?>
        </div>
        <div class="mt-6 pt-4 border-t text-right">
            <span class="text-gray-600">Total Amount:</span>
            <span class="font-bold text-2xl text-gray-800 ml-2">₹<?= number_format($order['total_amount']) ?></span>
        </div>
    </div>

    <!-- Right Column: Shipping & Status -->
    <div class="space-y-6">
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold mb-4 border-b pb-2">Shipping Details</h2>
            <p><strong>Name:</strong> <?= htmlspecialchars($order['name']) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?></p>
            <p><strong>Address:</strong><br><?= nl2br(htmlspecialchars($order['address'])) ?></p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold mb-4 border-b pb-2">Update Status</h2>
            <form id="status-form" class="flex items-center space-x-2">
                <select id="status-select" class="flex-grow border-gray-300 rounded-md shadow-sm">
                    <option value="Placed" <?= $order['status'] == 'Placed' ? 'selected' : '' ?>>Placed</option>
                    <option value="Dispatched" <?= $order['status'] == 'Dispatched' ? 'selected' : '' ?>>Dispatched</option>
                    <option value="Delivered" <?= $order['status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                    <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
                <button type="submit" class="bg-indigo-600 text-white py-2 px-4 rounded-lg">Update</button>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('status-form').onsubmit = async (e) => {
    e.preventDefault();
    showLoader();
    const status = document.getElementById('status-select').value;
    const formData = new FormData();
    formData.append('action', 'update_status');
    formData.append('order_id', <?= $order_id ?>);
    formData.append('status', status);

    const response = await fetch('order_detail.php', { method: 'POST', body: formData });
    const result = await response.json();
    hideLoader();
    showToast(result.message, result.status === 'success');
};
</script>

<?php require_once 'common/bottom.php'; ?>