<div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity duration-300 hidden lg:hidden"></div>

<aside id="sidebar" class="fixed top-0 left-0 h-full w-64 bg-gray-800 text-white shadow-xl z-40 transform -translate-x-full transition-transform duration-300 ease-in-out lg:translate-x-0 lg:relative lg:w-64">
    <div class="p-4 border-b border-gray-700 flex items-center">
        <i class="fas fa-shopping-cart text-2xl text-indigo-400"></i>
        <h2 class="ml-3 text-2xl font-bold">Quick Kart</h2>
    </div>
    <nav class="mt-4">
        <a href="index.php" class="flex items-center px-4 py-3 hover:bg-gray-700">
            <i class="fas fa-tachometer-alt w-6 text-center"></i><span class="ml-3">Dashboard</span>
        </a>
        <a href="category.php" class="flex items-center px-4 py-3 hover:bg-gray-700">
            <i class="fas fa-tags w-6 text-center"></i><span class="ml-3">Categories</span>
        </a>
        <a href="product.php" class="flex items-center px-4 py-3 hover:bg-gray-700">
            <i class="fas fa-box-open w-6 text-center"></i><span class="ml-3">Products</span>
        </a>
        <a href="order.php" class="flex items-center px-4 py-3 hover:bg-gray-700">
            <i class="fas fa-receipt w-6 text-center"></i><span class="ml-3">Orders</span>
        </a>
        <a href="user.php" class="flex items-center px-4 py-3 hover:bg-gray-700">
            <i class="fas fa-users w-6 text-center"></i><span class="ml-3">Users</span>
        </a>
        <a href="setting.php" class="flex items-center px-4 py-3 hover:bg-gray-700">
            <i class="fas fa-cog w-6 text-center"></i><span class="ml-3">Settings</span>
        </a>
    </nav>
    <div class="absolute bottom-0 w-full p-4 border-t border-gray-700">
        <a href="login.php?action=logout" class="flex items-center text-red-400 hover:text-red-300">
            <i class="fas fa-sign-out-alt w-6 text-center"></i><span class="ml-3">Logout</span>
        </a>
    </div>
</aside>