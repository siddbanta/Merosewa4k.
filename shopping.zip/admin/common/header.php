<?php
// This should be the first line in every admin file
require_once '../common/config.php';

// Security check: Redirect to login if not logged in as admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Admin Panel - Quick Kart</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* Shared styles from user panel */
        body { -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .loader-dots div { animation: 1.5s loader-dots infinite ease-in-out; }
        @keyframes loader-dots { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1.0); } }
        .loader-dots div:nth-child(1) { animation-delay: -0.32s; }
        .loader-dots div:nth-child(2) { animation-delay: -0.16s; }
    </style>
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col">
            <!-- Top Bar -->
            <header class="bg-white shadow-sm p-4 flex justify-between items-center lg:justify-end">
                <button id="menu-button" class="text-gray-600 text-xl lg:hidden">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="flex items-center space-x-4">
                    <span class="font-semibold text-gray-700">Welcome, Admin</span>
                    <a href="setting.php" class="text-gray-500 hover:text-indigo-600"><i class="fas fa-cog"></i></a>
                </div>
            </header>

            <!-- Content Area -->
            <main class="flex-1 p-4 lg:p-6">
                <!-- Global Loader Modal -->
                <div id="loader" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
                    <div class="bg-white p-6 rounded-lg shadow-xl flex items-center space-x-4">
                        <div class="loader-dots relative flex space-x-2">
                            <div class="w-3 h-3 bg-indigo-600 rounded-full"></div>
                            <div class="w-3 h-3 bg-indigo-600 rounded-full"></div>
                            <div class="w-3 h-3 bg-indigo-600 rounded-full"></div>
                        </div>
                        <span class="text-gray-700 font-medium">Loading...</span>
                    </div>
                </div>

                <!-- Global Toast Notification -->
                <div id="toast" class="hidden fixed top-5 right-5 bg-green-500 text-white py-2 px-4 rounded-lg shadow-lg z-50 transition-transform transform translate-x-full">
                    <span id="toast-message"></span>
                </div>