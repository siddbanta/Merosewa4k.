            </main>
        </div>
    </div>

<script>
    // --- ADMIN GLOBAL JS ---
    document.addEventListener('contextmenu', event => event.preventDefault());

    // Loader and Toast functions
    const loader = document.getElementById('loader');
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');

    function showLoader() { loader.classList.remove('hidden'); }
    function hideLoader() { loader.classList.add('hidden'); }

    function showToast(message, isSuccess = true) {
        toastMessage.innerText = message;
        toast.classList.remove('hidden', 'bg-red-500', 'bg-green-500', 'translate-x-full');
        toast.classList.add(isSuccess ? 'bg-green-500' : 'bg-red-500');
        setTimeout(() => { toast.classList.remove('translate-x-full'); }, 10);
        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => { toast.classList.add('hidden'); }, 300);
        }, 3000);
    }

    // Sidebar toggle logic for mobile
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');
    const menuButton = document.getElementById('menu-button');

    if (menuButton) {
        menuButton.addEventListener('click', () => {
            sidebar.classList.toggle('-translate-x-full');
            sidebarOverlay.classList.toggle('hidden');
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.add('-translate-x-full');
            sidebarOverlay.classList.add('hidden');
        });
    }
</script>
</body>
</html>