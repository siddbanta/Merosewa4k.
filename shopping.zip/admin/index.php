<?php
require_once 'common/header.php';

// Fetch stats
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'];
$total_revenue = $conn->query("SELECT SUM(total_amount) as sum FROM orders WHERE status = 'Delivered'")->fetch_assoc()['sum'] ?? 0;
$active_products = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
$cancellations = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'Cancelled'")->fetch_assoc()['count'];
$shipments = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'Dispatched'")->fetch_assoc()['count'];

$stats = [
    ['label' => 'Total Revenue', 'value' => '₹' . number_format($total_revenue), 'icon' => 'fa-rupee-sign', 'color' => 'bg-green-500'],
    ['label' => 'Total Orders', 'value' => $total_orders, 'icon' => 'fa-receipt', 'color' => 'bg-blue-500'],
    ['label' => 'Total Users', 'value' => $total_users, 'icon' => 'fa-users', 'color' => 'bg-indigo-500'],
    ['label' => 'Active Products', 'value' => $active_products, 'icon' => 'fa-box-open', 'color' => 'bg-purple-500'],
    ['label' => 'Active Shipments', 'value' => $shipments, 'icon' => 'fa-truck', 'color' => 'bg-yellow-500'],
    ['label' => 'Cancellations', 'value' => $cancellations, 'icon' => 'fa-times-circle', 'color' => 'bg-red-500'],
];
?>

<h1 class="text-2xl font-bold text-gray-800 mb-6">Dashboard</h1>

<!-- Stats Grid -->
<div class="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-6">
    <?php foreach ($stats as $stat): ?>
    <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4">
        <div class="w-12 h-12 rounded-full flex items-center justify-center <?= $stat['color'] ?> text-white">
            <i class="fas <?= $stat['icon'] ?> text-xl"></i>
        </div>
        <div>
            <p class="text-gray-500 text-sm font-medium"><?= $stat['label'] ?></p>
            <p class="text-2xl font-bold text-gray-800"><?= $stat['value'] ?></p>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Quick Actions -->
<div class="mt-8">
    <h2 class="text-xl font-semibold text-gray-700 mb-4">Quick Actions</h2>
    <div class="flex flex-wrap gap-4">
        <a href="product.php" class="bg-indigo-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-indigo-700 transition-colors">
            <i class="fas fa-plus-circle mr-2"></i>Add New Product
        </a>
        <a href="order.php" class="bg-gray-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-gray-800 transition-colors">
            <i class="fas fa-eye mr-2"></i>View Orders
        </a>
         <a href="user.php" class="bg-green-600 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-green-700 transition-colors">
            <i class="fas fa-user-cog mr-2"></i>Manage Users
        </a>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>